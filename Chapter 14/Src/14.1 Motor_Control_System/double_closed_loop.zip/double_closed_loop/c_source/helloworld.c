/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */

#include <stdio.h>
#include "platform.h"
#include "xparameters.h"
#include "xil_io.h"

void print(char *str);
extern char inbyte(void);

void init_motor_ctrlr()
{
	/*-------------speed loop parameters set---------------------------------------------*/
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 44), 0x0100);	//speed loop PID parameter -- p fix_16_8
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 48), 0x00000100);	//speed loop PID parameter -- i fix_16_8
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 52), 0x00000100);	//speed loop PID parameter -- d fix_16_8
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 56), 500);	//speed loop iLimit -- i_speed_ilimit fix_16_0
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 60), 900);	//current max  -- i_current_max fix_16_0

	/*-------------current loop parameters set--------------------------------------------*/
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 80), 9);		//current loop calculator cycles = value + 1
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 84), 0x00000000);	//current loop PID parameter -- p fix_16_8
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 88), 0x00000000);	//current loop PID parameter -- i fix_16_8
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 92), 0x00000000);	//current loop PID parameter -- d fix_16_8
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 96), 0x0000efff);	//low pass filter parameter -- a ufix_16_15
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 100), 0x00000000);	//low pass filter parameter -- b ufix_16_15
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 104), 0x00000000);	//PWM max duty parameter  ufix_16_0

	/*-------------control REG  parameters set--------------------------------------------*/
	//pwm
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 12), 0);	//PWM preDiv parameter  ufix_16_0
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 16), 5000);	//PWM max duty parameter  ufix_16_0
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 8), 0x00000002);	//PWM control REG  ufix_16_0
	//motorCtrlr reg
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 0), 0x00000002);	//IP control REG  ufix_16_0, enable Initialize SPI module
}
void start_motor_ctrlr()
{
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 0), 0x00000003);	//IP control REG  ufix_16_0, start IP
	//motorCtrlr reg
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 8), 0x00000003);	//PWM control REG  ufix_16_0, start PWM output
}

void set_motor_speed()
{
	Xil_Out32((XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 40), 10);	//set motor speed REG
}

int main()
{
	u32 xs;//, read_num;
    init_platform();
    print("Hello World\n\r");
    init_motor_ctrlr();

    while(xs == 0)
    {
        xs = Xil_In32(XPAR_MOTOR_CTRLR_IP_0_BASEADDR + 4);
    }

    if(xs == 0x00000001)
    	print("Initialization Done\n\r");

    set_motor_speed();
    while(inbyte() != '5')
    {
    }

    start_motor_ctrlr();

    while(inbyte() != '0')
    {
    }

    cleanup_platform();

    return 0;
}
