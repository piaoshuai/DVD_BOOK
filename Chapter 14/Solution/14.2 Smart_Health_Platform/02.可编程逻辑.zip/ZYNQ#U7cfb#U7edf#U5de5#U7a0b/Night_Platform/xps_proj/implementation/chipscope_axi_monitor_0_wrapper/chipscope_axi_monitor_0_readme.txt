The following files were generated for 'chipscope_axi_monitor_0' in directory
C:\xup\Zed\PWM_IP_test\PWM_IP_test.srcs\sources_1\edk\system\implementation\chipscope_axi_monitor_0_wrapper\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * chipscope_axi_monitor_0.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * chipscope_axi_monitor_0.cdc
   * chipscope_axi_monitor_0.constraints/chipscope_axi_monitor_0.ucf
   * chipscope_axi_monitor_0.constraints/chipscope_axi_monitor_0.xdc
   * chipscope_axi_monitor_0.ncf
   * chipscope_axi_monitor_0.ngc
   * chipscope_axi_monitor_0.ucf
   * chipscope_axi_monitor_0.vhd
   * chipscope_axi_monitor_0.vho
   * chipscope_axi_monitor_0.xdc
   * chipscope_axi_monitor_0_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * chipscope_axi_monitor_0.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * chipscope_axi_monitor_0.gise
   * chipscope_axi_monitor_0.xise

Deliver Readme:
   Readme file for the IP.

   * chipscope_axi_monitor_0_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * chipscope_axi_monitor_0_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

