/*********************************************************
File Name:    night_ekg_controller.c
Author:       Nightmare@EEFOCUS
Version:      v0.1 2012-10-10
Description:  Driver of Night EKG Controller.

*********************************************************/
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/ioport.h>
#include <linux/of.h>
#include <linux/fs.h>
#include <asm/io.h>

#define DEVICE_NAME         "night_ekg_controller"

#define NIGHT_EKG_PHY_ADDR    0x78100000 //Modify the address to your peripheral
#define NIGHT_EKG_REG_NUM     4
#define NIGHT_EKG_REG_WIDTH   32

static void __iomem *EKG_Regs;

static int Night_EKG_open(struct inode * inode , struct file * filp)
{
  return 0;
}

static int Night_EKG_release(struct inode * inode, struct file *filp)
{
  return 0;
}

static int Night_EKG_read(struct file *filp, char *buffer, size_t length, loff_t * offset)
{
  int bytes_read = 0; 
  int i=0;
  
  if (filp->f_flags & O_NONBLOCK)
    return -EAGAIN;
  
  if (length>0 && length<=(NIGHT_EKG_REG_NUM*4))
  {
    for(i=0;i<length;i++)
    {
      *(buffer+i)=(char)ioread8(EKG_Regs+i);
    }
    bytes_read=i;
  }
  return bytes_read;
}

static int Night_EKG_ioctl(struct file *filp, unsigned int reg_num, unsigned long arg)
{
  if(reg_num>=0 && reg_num<NIGHT_EKG_REG_NUM)
  {
    iowrite32(arg, EKG_Regs+reg_num*4);
    //printk("NightEKG: Write 0x%x to 0x%x!\n", arg, EKG_Regs+reg_num*4);
  }
  else
  {
    printk("NightEKG:[ERROR] Wrong register number!\n");
    return -EINVAL;
  }  
  return 0;
}

static const struct file_operations Night_EKG_fops =
{
  .owner = THIS_MODULE,
  .open = Night_EKG_open,
  .release = Night_EKG_release,
  .read = Night_EKG_read,
  .unlocked_ioctl = Night_EKG_ioctl,  
};

static struct miscdevice Night_EKG_dev =
{
  .minor = MISC_DYNAMIC_MINOR,
  .name = DEVICE_NAME,
  .fops = &Night_EKG_fops,
};

int __init Night_EKG_init(void)
{
  int ret, val;
  long volt;
/*
  //Request I/O memory (Not necessary)
  if (!request_mem_region(EKG_Regs, NIGHT_EKG_REG_NUM*NIGHT_EKG_REG_WIDTH, "my_gpio"))
  {
    printk("NightEKG:[ERROR] Failed to request I/O memory\n");
    return -EBUSY;
  }
*/
  
  //Map device to the virtual address of kernel
  EKG_Regs = ioremap(NIGHT_EKG_PHY_ADDR, 0xFFFF); /* Verify it's non-null! */
  printk("NightEKG: Access address to device is:0x%x\n", (unsigned int)EKG_Regs);
  if(EKG_Regs == NULL)
  {
    printk("NightEKG:[ERROR] Access address is NULL!\n");
    return -EIO;
  }  
 
  //Regist misc device
  ret = misc_register(&Night_EKG_dev);
  if (ret)
  {
    printk("NightEKG:[ERROR] Misc device register failed\n");
    return ret;
  }

  //Show the current voltage value
  val = 0x281;
  iowrite32(val, EKG_Regs);

	do{
		ioread32(EKG_Regs+4);
	}while( !(val & 0x1) );
	val = ioread32(EKG_Regs+8);
	volt = (long)val*6000/65535;
	printk("NightEKG: Module init complete. ADC Voltage = %ldmV.\n", volt);	

  return 0; /* Success */
}

void __exit Night_EKG_exit(void)
{
  iounmap(EKG_Regs);
  //release_mem_region(EKG_Regs, NIGHT_EKG_REG_NUM*NIGHT_EKG_REG_WIDTH);
  misc_deregister(&Night_EKG_dev);
  
  printk("NightEKG: Module exit\n");
}

module_init(Night_EKG_init);
module_exit(Night_EKG_exit);

MODULE_AUTHOR("Nightmare");
MODULE_ALIAS("Night EKG Controller");
MODULE_DESCRIPTION("Zedboard EKG AFE Controller module");
MODULE_LICENSE("GPL");
