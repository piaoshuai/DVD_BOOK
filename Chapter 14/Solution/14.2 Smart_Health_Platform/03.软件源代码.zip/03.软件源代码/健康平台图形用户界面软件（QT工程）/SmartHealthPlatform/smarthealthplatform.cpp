#include <QtCore>
#include <QBitmap>

#include "smarthealthplatform.h"
#include "ui_smarthealthplatform.h"

//#define SOFT_TIMER

SmartHealthPlatform::SmartHealthPlatform(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SmartHealthPlatform)
{
    ui->setupUi(this);
    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setWindowState(Qt::WindowFullScreen);
    this->InitGraph();
}


SmartHealthPlatform::~SmartHealthPlatform()
{
    delete ui;    
}

void SmartHealthPlatform::InitGraph()
{
    QPalette palette;
    this->setAutoFillBackground(true);
    palette.setBrush(QPalette::Background, QBrush(QPixmap("/sd_part2/image/BackGround.png")));
    this->setPalette(palette);

    QPixmap PicEKG("/sd_part2/image/Button_EKG.png");
    ui->toolButtonEKG->setStyleSheet("QToolButton{border:0px;}");
    ui->toolButtonEKG->resize(PicEKG.height(),PicEKG.width());
    ui->toolButtonEKG->setIconSize(QSize(PicEKG.height(),PicEKG.width()));
    ui->toolButtonEKG->setIcon(QIcon(PicEKG));
    ui->toolButtonEKG->move(870,690);

    QPixmap PicPO("/sd_part2/image/Button_PO.png");
    ui->toolButtonPO->setStyleSheet("QToolButton{border:0px;}");
    ui->toolButtonPO->resize(PicPO.height(),PicPO.width());
    ui->toolButtonPO->setIconSize(QSize(PicPO.height(),PicPO.width()));
    ui->toolButtonPO->setIcon(QIcon(PicPO));
    ui->toolButtonPO->move(1020,690);

    QPixmap PicBP("/sd_part2/image/Button_BP.png");
    ui->toolButtonBP->setStyleSheet("QToolButton{border:0px;}");
    ui->toolButtonBP->resize(PicBP.height(),PicBP.width());
    ui->toolButtonBP->setIconSize(QSize(PicBP.height(),PicBP.width()));
    ui->toolButtonBP->setIcon(QIcon(PicBP));
    ui->toolButtonBP->move(1170,695);

    QPixmap PicExit("/sd_part2/image/Button_Exit.png");
    ui->toolButtonExit->setStyleSheet("QToolButton{border:0px;}");
    ui->toolButtonExit->resize(PicExit.height(),PicExit.width());
    ui->toolButtonExit->setIconSize(QSize(PicExit.height(),PicExit.width()));
    ui->toolButtonExit->setIcon(QIcon(PicExit));
    ui->toolButtonExit->move(1305,690);
}

void SmartHealthPlatform::on_toolButtonEKG_clicked()
{


#ifdef EKG_CONTROLLER_H
    #ifdef SOFT_TIMER
    //Software Sampling Timer
    if(EKG_Init() == 0)
    {
        frmEKG.InitData();
        frmEKG.TimerRefresh->start(1);
        frmEKG.move(120,50);
        frmEKG.exec();
    }
    #else
    //Hardware Sampling Timer
    if(EKG_Init() == 0)
    {
        frmEKG.InitData();
        //frmEKG.TimerRefresh->start(1);
        frmEKG.move(120,50);
        frmEKG.ReadDataThread();
        frmEKG.exec();
    }
    #endif
#else
    frmEKG.InitData();
    frmEKG.TimerRefresh->start(1);
    frmEKG.move(120,50);
    frmEKG.exec();
#endif
}

void SmartHealthPlatform::on_toolButtonExit_clicked()
{
    this->close();
}


