#ifndef EKG_MONITOR_H
#define EKG_MONITOR_H

#include <QDialog>

#include "night_thread.h"

namespace Ui {
class EKG_Monitor;
}

class EKG_Monitor : public QDialog
{
    Q_OBJECT
    
public:
    explicit EKG_Monitor(QWidget *parent = 0);
    ~EKG_Monitor();

    QTimer *TimerRefresh;

    NightThread th_Read;

    void InitData();
    void EKG_Monitor_Init();
    quint16 ReadData();
    void ReadDataLoop();
    void ReadDataThread();

private slots:
    void TimerUpdated();
    
private:
    Ui::EKG_Monitor *ui;

    void paintEvent(QPaintEvent *);



};

#endif // EKG_MONITOR_H
