#ifndef EKG_CONTROLLER_H
//#define EKG_CONTROLLER_H
#include <QtCore>

int EKG_Init(void);
void EKG_Release(void);
int EKG_ReadReg(int reg_num);
void EKG_WriteReg(int reg_num, int val);
int EKG_GetStatus(void);
int EKG_ReadData(void);
void EKG_StartConvert(void);
void EKG_WatiCvntComplete(void);
void EKG_WatiTimerOut(void);

extern quint16 EKG_Data[];
extern int Data_Index;

#define EKG_DATA_LEN    1200
#define EKG_DATA_MAX    65535
#define EKG_WIDTH       1200
#define EKG_HEIGHT      800

#endif // EKG_CONTROLLER_H
