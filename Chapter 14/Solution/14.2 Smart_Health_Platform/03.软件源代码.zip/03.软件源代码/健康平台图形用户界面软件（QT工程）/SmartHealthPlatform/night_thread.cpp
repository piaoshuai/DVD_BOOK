#include "night_thread.h"


void NightThread::run()
{
    //
    int data=0;

    while(!Thead_Fin_Flag)
    {
        #ifdef EKG_CONTROLLER_H
            EKG_StartConvert();
            EKG_WatiTimerOut();
            data = EKG_HEIGHT*3/2-EKG_ReadData()*3*EKG_HEIGHT/EKG_DATA_MAX;
        #else
            data = EKG_HEIGHT*3/2-(qrand()%(EKG_DATA_MAX/3)+EKG_DATA_MAX/6)*3*EKG_HEIGHT/EKG_DATA_MAX;
        #endif

        //for test
        //usleep(1000);
        //Using lock to protect public val
        EKG_Data_Lock.lockForWrite();
        EKG_Data[Data_Index]=data;
        Data_Index++;
        if(Data_Index>=EKG_DATA_LEN)
        {
            Data_Index=0;
        }
        EKG_Data_Lock.unlock();
     }

}
