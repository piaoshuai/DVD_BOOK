#include <QtCore>
#include <QPainter>
#include "ekg_monitor.h"
#include "ui_ekg_monitor.h"

EKG_Monitor::EKG_Monitor(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::EKG_Monitor)
{
    ui->setupUi(this);

    this->InitData();
    TimerRefresh = new QTimer(this);
    connect(TimerRefresh,SIGNAL(timeout()),this,SLOT(TimerUpdated()));
}

EKG_Monitor::~EKG_Monitor()
{
#ifdef EKG_CONTROLLER_H
    EKG_Release();
#endif
    delete ui;
}

void EKG_Monitor::TimerUpdated()
{
    EKG_Data[Data_Index]=ReadData();
    Data_Index++;
    if(Data_Index>=EKG_DATA_LEN)
    {
        Data_Index=0;
    }
    update();
}

void EKG_Monitor::paintEvent(QPaintEvent *)
{
    QPainter pt(this);
    int i;
    QPen pn;
    QBrush bs;

    pt.setRenderHint(QPainter::Antialiasing, true);

    //Draw Lines
    pn.setColor(Qt::lightGray);
    pn.setWidth(2);
    pn.setStyle(Qt::DashLine);
    pt.setPen(pn);
    pt.drawRect(0,0,EKG_WIDTH,EKG_HEIGHT);
    //Horizontal
    pt.drawLine(0, EKG_HEIGHT/4, EKG_WIDTH, EKG_HEIGHT/4);
    pt.drawLine(0, EKG_HEIGHT/2, EKG_WIDTH, EKG_HEIGHT/2);
    pt.drawLine(0, EKG_HEIGHT*3/4, EKG_WIDTH, EKG_HEIGHT*3/4);
    //Vertical
    pt.drawLine(EKG_WIDTH/4, 0, EKG_WIDTH/4, EKG_HEIGHT);
    pt.drawLine(EKG_WIDTH/2, 0, EKG_WIDTH/2, EKG_HEIGHT);
    pt.drawLine(EKG_WIDTH*3/4, 0, EKG_WIDTH*3/4, EKG_HEIGHT);

    //Draw EKG Wave
    pn.setColor(Qt::green);
    pn.setStyle(Qt::SolidLine);
    pn.setWidth(2);
    pt.setPen(pn);

     for(i=0;i<EKG_DATA_LEN-1;i++)
    {
        pt.drawLine(i,EKG_Data[i],(i+1),EKG_Data[i+1]);
    }
}

quint16 EKG_Monitor::ReadData()
{
    //Just for test
    int data=0;

#ifdef EKG_CONTROLLER_H
    EKG_StartConvert();
    EKG_WatiTimerOut();
    data = EKG_HEIGHT*3/2-EKG_ReadData()*3*EKG_HEIGHT/EKG_DATA_MAX;
#else
    data = EKG_HEIGHT*3/2-(qrand()%(EKG_DATA_MAX/3)+EKG_DATA_MAX/6)*3*EKG_HEIGHT/EKG_DATA_MAX;
#endif

    ui->label_HB->setText(QString::number(data));
    if(data>EKG_HEIGHT) data = EKG_HEIGHT;
    if(data<0) data = 0;

    return ((qint16)data);
}

void EKG_Monitor::ReadDataLoop()
{
#ifdef EKG_CONTROLLER_H
    int i;
    for(i=0;i<EKG_DATA_LEN;i++)
    {
        EKG_Data[Data_Index]=ReadData();
        Data_Index++;
        if(Data_Index>=EKG_DATA_LEN)
        {
            Data_Index=0;
        }
    }
    update();
#endif
}

void EKG_Monitor::ReadDataThread()
{
    th_Read.start();
}

void EKG_Monitor::InitData()
{
    int i;
    ui->label_HB->setText("70");
    ui->label_HB->setStyleSheet("color:cyan");
    Data_Index = 0;
    for(i=0;i<EKG_DATA_LEN;i++)
    {
        EKG_Data[i] = EKG_HEIGHT/2;
    }
}
