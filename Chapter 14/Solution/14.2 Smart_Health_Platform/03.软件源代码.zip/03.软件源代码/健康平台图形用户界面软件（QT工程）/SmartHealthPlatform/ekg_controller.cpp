#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include "ekg_controller.h"
#include <QMessageBox>

#define REG_NUM         4
#define START_CMD       0x241 //Start_Bit=1, F_SPI=4MHz, P_Samp=1ms, GPIO=101


quint16 EKG_Data[EKG_DATA_LEN];
int Data_Index;
int night_ekg_fd = 0;

int EKG_Init(void)
{
    QMessageBox msg;
    
    night_ekg_fd = open("/dev/night_ekg_controller", 0);
    if(night_ekg_fd<0)
    {
        msg.setText("[ERROR] Can't open device.");
        msg.exec();
        return 1; //Failed
    }
    return 0; //Success
} 

void EKG_Release(void)
{
    close(night_ekg_fd);
}

int EKG_ReadReg(int reg_num)
{
    int ret, rd32_buf = 0;
    char rd8_buf[REG_NUM*4];
    
    QMessageBox msg;
    
    ret = read(night_ekg_fd, rd8_buf, sizeof(rd8_buf));
    if(ret != sizeof(rd8_buf))
    {
        msg.setText("[ERROR] Read bytes count not correct.");
        msg.exec();
    }
    
    rd32_buf = (int)rd8_buf[reg_num*4] + ((int)rd8_buf[reg_num*4+1]<<8) 
                + ((int)rd8_buf[reg_num*4+2]<<16) + ((int)rd8_buf[reg_num*4+3]<<24);
    return(rd32_buf);
}

void EKG_WriteReg(int reg_num, int val)
{   
    ioctl(night_ekg_fd, reg_num, val);
}

int EKG_GetStatus(void)
{
    return EKG_ReadReg(1);
}

int EKG_ReadData(void)
{
    return EKG_ReadReg(2);
}

void EKG_StartConvert(void)
{
    EKG_WriteReg(0, START_CMD);
}

void EKG_WatiCvntComplete(void)
{
    int val;
    do
    {
        val = EKG_GetStatus(); 
    }
    while( !(val & 0x1) );
}

void EKG_WatiTimerOut(void)
{
    int val;
    do
    {
        val = EKG_GetStatus();
    }
    while( !(val & (0x1<<2)) );
}
