#ifndef SMARTHEALTHPLATFORM_H
#define SMARTHEALTHPLATFORM_H

#include <QMainWindow>
#include "ekg_monitor.h"

namespace Ui {
class SmartHealthPlatform;
}

class SmartHealthPlatform : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit SmartHealthPlatform(QWidget *parent = 0);
    ~SmartHealthPlatform();

    EKG_Monitor frmEKG;
    
private slots:
    void on_toolButtonEKG_clicked();
    void on_toolButtonExit_clicked();


private:
    Ui::SmartHealthPlatform *ui;
    void InitGraph();
};

#endif // SMARTHEALTHPLATFORM_H
