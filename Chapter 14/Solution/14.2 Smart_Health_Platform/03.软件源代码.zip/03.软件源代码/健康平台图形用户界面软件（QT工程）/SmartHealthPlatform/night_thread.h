#ifndef EKG_THREAD_H
#define EKG_THREAD_H

#include "ekg_controller.h"
#include <QThread>
#include <QReadWriteLock>

//Night_Thread
class NightThread : public QThread
{
    Q_OBJECT

public:
    //Thread Finished Flag
    bool Thead_Fin_Flag;
    //EKG Buffer Data Lock
    QReadWriteLock EKG_Data_Lock;

protected:
    void run();
};

#endif // EKG_THREAD_H
