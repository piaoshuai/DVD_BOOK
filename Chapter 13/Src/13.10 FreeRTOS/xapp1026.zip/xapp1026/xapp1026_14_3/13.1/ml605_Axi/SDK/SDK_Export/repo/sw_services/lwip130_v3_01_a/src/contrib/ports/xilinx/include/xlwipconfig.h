#ifndef __XLWIPCONFIG_H_
#define __XLWIPCONFIG_H_

/* this is a generated file: do not modify */

#define XLWIP_CONFIG_INCLUDE_EMACLITE 1

#endif
