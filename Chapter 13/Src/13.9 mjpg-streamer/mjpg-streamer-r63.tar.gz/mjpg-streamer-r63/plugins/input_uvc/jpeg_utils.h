int compress_yuyv_to_jpeg(struct vdIn *vd, unsigned char *buffer, int size, int quality);
